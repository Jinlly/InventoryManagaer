﻿namespace Lab6
{
    partial class Manager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.storageGridView = new System.Windows.Forms.DataGridView();
            this.inventoraManagerDataSet = new Lab6.InventoraManagerDataSet();
            this.storageTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.storage_TableTableAdapter = new Lab6.InventoraManagerDataSetTableAdapters.Storage_TableTableAdapter();
            this.refillLabel = new System.Windows.Forms.Label();
            this.refillBtn = new System.Windows.Forms.Button();
            this.priceManagerLabel = new System.Windows.Forms.Label();
            this.nameSerchLabel = new System.Windows.Forms.Label();
            this.searchBtn = new System.Windows.Forms.Button();
            this.refundBox = new System.Windows.Forms.RichTextBox();
            this.refundLabel = new System.Windows.Forms.Label();
            this.newPriceBox = new System.Windows.Forms.RichTextBox();
            this.oldPriceBox = new System.Windows.Forms.RichTextBox();
            this.priceChangeBtn = new System.Windows.Forms.Button();
            this.oldPriceLabel = new System.Windows.Forms.Label();
            this.newPriceLable = new System.Windows.Forms.Label();
            this.refundManageBtn = new System.Windows.Forms.Button();
            this.refillNumberLabel = new System.Windows.Forms.Label();
            this.refillBox = new System.Windows.Forms.RichTextBox();
            this.refillNumberBox = new System.Windows.Forms.RichTextBox();
            this.orderBtn = new System.Windows.Forms.Button();
            this.IDSearchBox = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.searchingDesBox = new System.Windows.Forms.RichTextBox();
            this.searchBrandBox = new System.Windows.Forms.RichTextBox();
            this.searchingLabelDes = new System.Windows.Forms.Label();
            this.searchingBrandLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.storageGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoraManagerDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storageTableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // storageGridView
            // 
            this.storageGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.storageGridView.Location = new System.Drawing.Point(314, 51);
            this.storageGridView.Name = "storageGridView";
            this.storageGridView.Size = new System.Drawing.Size(474, 270);
            this.storageGridView.TabIndex = 6;
            this.storageGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.storageGridView_CellContentClick);
            // 
            // inventoraManagerDataSet
            // 
            this.inventoraManagerDataSet.DataSetName = "InventoraManagerDataSet";
            this.inventoraManagerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // storageTableBindingSource
            // 
            this.storageTableBindingSource.DataMember = "Storage_Table";
            this.storageTableBindingSource.DataSource = this.inventoraManagerDataSet;
            // 
            // storage_TableTableAdapter
            // 
            this.storage_TableTableAdapter.ClearBeforeFill = true;
            // 
            // refillLabel
            // 
            this.refillLabel.AutoSize = true;
            this.refillLabel.Location = new System.Drawing.Point(33, 18);
            this.refillLabel.Name = "refillLabel";
            this.refillLabel.Size = new System.Drawing.Size(87, 13);
            this.refillLabel.TabIndex = 7;
            this.refillLabel.Text = "Refill Product ID:";
            // 
            // refillBtn
            // 
            this.refillBtn.Location = new System.Drawing.Point(31, 129);
            this.refillBtn.Name = "refillBtn";
            this.refillBtn.Size = new System.Drawing.Size(75, 23);
            this.refillBtn.TabIndex = 9;
            this.refillBtn.Text = "Refill";
            this.refillBtn.UseVisualStyleBackColor = true;
            this.refillBtn.Click += new System.EventHandler(this.refillBtn_Click);
            // 
            // priceManagerLabel
            // 
            this.priceManagerLabel.AutoSize = true;
            this.priceManagerLabel.Location = new System.Drawing.Point(45, 190);
            this.priceManagerLabel.Name = "priceManagerLabel";
            this.priceManagerLabel.Size = new System.Drawing.Size(76, 13);
            this.priceManagerLabel.TabIndex = 11;
            this.priceManagerLabel.Text = "Price Manage:";
            // 
            // nameSerchLabel
            // 
            this.nameSerchLabel.AutoSize = true;
            this.nameSerchLabel.Location = new System.Drawing.Point(45, 273);
            this.nameSerchLabel.Name = "nameSerchLabel";
            this.nameSerchLabel.Size = new System.Drawing.Size(44, 13);
            this.nameSerchLabel.TabIndex = 13;
            this.nameSerchLabel.Text = "Item ID:";
            // 
            // searchBtn
            // 
            this.searchBtn.Location = new System.Drawing.Point(110, 330);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(75, 23);
            this.searchBtn.TabIndex = 14;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseVisualStyleBackColor = true;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // refundBox
            // 
            this.refundBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refundBox.Location = new System.Drawing.Point(411, 327);
            this.refundBox.Name = "refundBox";
            this.refundBox.Size = new System.Drawing.Size(88, 57);
            this.refundBox.TabIndex = 15;
            this.refundBox.Text = "";
            // 
            // refundLabel
            // 
            this.refundLabel.AutoSize = true;
            this.refundLabel.Location = new System.Drawing.Point(317, 330);
            this.refundLabel.Name = "refundLabel";
            this.refundLabel.Size = new System.Drawing.Size(88, 13);
            this.refundLabel.TabIndex = 16;
            this.refundLabel.Text = "Refund Request:";
            // 
            // newPriceBox
            // 
            this.newPriceBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newPriceBox.Location = new System.Drawing.Point(191, 351);
            this.newPriceBox.Name = "newPriceBox";
            this.newPriceBox.Size = new System.Drawing.Size(64, 33);
            this.newPriceBox.TabIndex = 17;
            this.newPriceBox.Text = "";
            this.newPriceBox.TextChanged += new System.EventHandler(this.newPriceBox_TextChanged);
            // 
            // oldPriceBox
            // 
            this.oldPriceBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.oldPriceBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oldPriceBox.Location = new System.Drawing.Point(47, 354);
            this.oldPriceBox.Name = "oldPriceBox";
            this.oldPriceBox.ReadOnly = true;
            this.oldPriceBox.Size = new System.Drawing.Size(64, 33);
            this.oldPriceBox.TabIndex = 18;
            this.oldPriceBox.Text = "";
            this.oldPriceBox.TextChanged += new System.EventHandler(this.oldPriceBox_TextChanged);
            // 
            // priceChangeBtn
            // 
            this.priceChangeBtn.Location = new System.Drawing.Point(110, 391);
            this.priceChangeBtn.Name = "priceChangeBtn";
            this.priceChangeBtn.Size = new System.Drawing.Size(75, 23);
            this.priceChangeBtn.TabIndex = 19;
            this.priceChangeBtn.Text = "Change";
            this.priceChangeBtn.UseVisualStyleBackColor = true;
            this.priceChangeBtn.Click += new System.EventHandler(this.priceChangeBtn_Click);
            // 
            // oldPriceLabel
            // 
            this.oldPriceLabel.AutoSize = true;
            this.oldPriceLabel.Location = new System.Drawing.Point(51, 335);
            this.oldPriceLabel.Name = "oldPriceLabel";
            this.oldPriceLabel.Size = new System.Drawing.Size(53, 13);
            this.oldPriceLabel.TabIndex = 20;
            this.oldPriceLabel.Text = "Old Price:";
            // 
            // newPriceLable
            // 
            this.newPriceLable.AutoSize = true;
            this.newPriceLable.Location = new System.Drawing.Point(196, 335);
            this.newPriceLable.Name = "newPriceLable";
            this.newPriceLable.Size = new System.Drawing.Size(59, 13);
            this.newPriceLable.TabIndex = 21;
            this.newPriceLable.Text = "New Price:";
            // 
            // refundManageBtn
            // 
            this.refundManageBtn.Location = new System.Drawing.Point(330, 354);
            this.refundManageBtn.Name = "refundManageBtn";
            this.refundManageBtn.Size = new System.Drawing.Size(75, 23);
            this.refundManageBtn.TabIndex = 22;
            this.refundManageBtn.Text = "Check";
            this.refundManageBtn.UseVisualStyleBackColor = true;
            // 
            // refillNumberLabel
            // 
            this.refillNumberLabel.AutoSize = true;
            this.refillNumberLabel.Location = new System.Drawing.Point(33, 72);
            this.refillNumberLabel.Name = "refillNumberLabel";
            this.refillNumberLabel.Size = new System.Drawing.Size(73, 13);
            this.refillNumberLabel.TabIndex = 23;
            this.refillNumberLabel.Text = "Refill Number:";
            // 
            // refillBox
            // 
            this.refillBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refillBox.Location = new System.Drawing.Point(33, 34);
            this.refillBox.Name = "refillBox";
            this.refillBox.Size = new System.Drawing.Size(210, 35);
            this.refillBox.TabIndex = 24;
            this.refillBox.Text = "";
            this.refillBox.TextChanged += new System.EventHandler(this.refillBox_TextChanged);
            // 
            // refillNumberBox
            // 
            this.refillNumberBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refillNumberBox.Location = new System.Drawing.Point(33, 88);
            this.refillNumberBox.Name = "refillNumberBox";
            this.refillNumberBox.Size = new System.Drawing.Size(210, 35);
            this.refillNumberBox.TabIndex = 25;
            this.refillNumberBox.Text = "";
            this.refillNumberBox.TextChanged += new System.EventHandler(this.refillNumberBox_TextChanged);
            // 
            // orderBtn
            // 
            this.orderBtn.Location = new System.Drawing.Point(168, 129);
            this.orderBtn.Name = "orderBtn";
            this.orderBtn.Size = new System.Drawing.Size(75, 23);
            this.orderBtn.TabIndex = 26;
            this.orderBtn.Text = "Order New";
            this.orderBtn.UseVisualStyleBackColor = true;
            this.orderBtn.Click += new System.EventHandler(this.orderBtn_Click);
            // 
            // IDSearchBox
            // 
            this.IDSearchBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.IDSearchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IDSearchBox.Location = new System.Drawing.Point(47, 289);
            this.IDSearchBox.Name = "IDSearchBox";
            this.IDSearchBox.ReadOnly = true;
            this.IDSearchBox.Size = new System.Drawing.Size(210, 35);
            this.IDSearchBox.TabIndex = 27;
            this.IDSearchBox.Text = "";
            this.IDSearchBox.TextChanged += new System.EventHandler(this.IDSearchBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(314, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 18);
            this.label1.TabIndex = 28;
            this.label1.Text = "On Stock:";
            // 
            // searchingDesBox
            // 
            this.searchingDesBox.Location = new System.Drawing.Point(48, 237);
            this.searchingDesBox.Name = "searchingDesBox";
            this.searchingDesBox.Size = new System.Drawing.Size(83, 33);
            this.searchingDesBox.TabIndex = 29;
            this.searchingDesBox.Text = "";
            this.searchingDesBox.TextChanged += new System.EventHandler(this.searchingDesBox_TextChanged);
            // 
            // searchBrandBox
            // 
            this.searchBrandBox.Location = new System.Drawing.Point(168, 237);
            this.searchBrandBox.Name = "searchBrandBox";
            this.searchBrandBox.Size = new System.Drawing.Size(89, 33);
            this.searchBrandBox.TabIndex = 30;
            this.searchBrandBox.Text = "";
            this.searchBrandBox.TextChanged += new System.EventHandler(this.searchBrandBox_TextChanged);
            // 
            // searchingLabelDes
            // 
            this.searchingLabelDes.AutoSize = true;
            this.searchingLabelDes.Location = new System.Drawing.Point(17, 221);
            this.searchingLabelDes.Name = "searchingLabelDes";
            this.searchingLabelDes.Size = new System.Drawing.Size(114, 13);
            this.searchingLabelDes.TabIndex = 31;
            this.searchingLabelDes.Text = "Searching Description:";
            // 
            // searchingBrandLabel
            // 
            this.searchingBrandLabel.AutoSize = true;
            this.searchingBrandLabel.Location = new System.Drawing.Point(168, 221);
            this.searchingBrandLabel.Name = "searchingBrandLabel";
            this.searchingBrandLabel.Size = new System.Drawing.Size(89, 13);
            this.searchingBrandLabel.TabIndex = 32;
            this.searchingBrandLabel.Text = "Searching Brand:";
            // 
            // Manager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.searchingBrandLabel);
            this.Controls.Add(this.searchingLabelDes);
            this.Controls.Add(this.searchBrandBox);
            this.Controls.Add(this.searchingDesBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.IDSearchBox);
            this.Controls.Add(this.orderBtn);
            this.Controls.Add(this.refillNumberBox);
            this.Controls.Add(this.refillBox);
            this.Controls.Add(this.refillNumberLabel);
            this.Controls.Add(this.refundManageBtn);
            this.Controls.Add(this.newPriceLable);
            this.Controls.Add(this.oldPriceLabel);
            this.Controls.Add(this.priceChangeBtn);
            this.Controls.Add(this.oldPriceBox);
            this.Controls.Add(this.newPriceBox);
            this.Controls.Add(this.refundLabel);
            this.Controls.Add(this.refundBox);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.nameSerchLabel);
            this.Controls.Add(this.priceManagerLabel);
            this.Controls.Add(this.refillBtn);
            this.Controls.Add(this.refillLabel);
            this.Controls.Add(this.storageGridView);
            this.Name = "Manager";
            this.Text = "Manager";
            this.Load += new System.EventHandler(this.Manager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.storageGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoraManagerDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storageTableBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView storageGridView;
        private InventoraManagerDataSet inventoraManagerDataSet;
        private System.Windows.Forms.BindingSource storageTableBindingSource;
        private InventoraManagerDataSetTableAdapters.Storage_TableTableAdapter storage_TableTableAdapter;
        private System.Windows.Forms.Label refillLabel;
        private System.Windows.Forms.Button refillBtn;
        private System.Windows.Forms.Label priceManagerLabel;
        private System.Windows.Forms.Label nameSerchLabel;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.RichTextBox refundBox;
        private System.Windows.Forms.Label refundLabel;
        private System.Windows.Forms.RichTextBox newPriceBox;
        private System.Windows.Forms.RichTextBox oldPriceBox;
        private System.Windows.Forms.Button priceChangeBtn;
        private System.Windows.Forms.Label oldPriceLabel;
        private System.Windows.Forms.Label newPriceLable;
        private System.Windows.Forms.Button refundManageBtn;
        private System.Windows.Forms.Label refillNumberLabel;
        private System.Windows.Forms.RichTextBox refillBox;
        private System.Windows.Forms.RichTextBox refillNumberBox;
        private System.Windows.Forms.Button orderBtn;
        private System.Windows.Forms.RichTextBox IDSearchBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox searchingDesBox;
        private System.Windows.Forms.RichTextBox searchBrandBox;
        private System.Windows.Forms.Label searchingLabelDes;
        private System.Windows.Forms.Label searchingBrandLabel;
    }
}