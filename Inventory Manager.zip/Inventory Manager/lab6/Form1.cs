﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class logInPage : Form
    {
        public logInPage()
        {
            InitializeComponent();
        }
        private void userNameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void passwordBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            customerPage customerForm = new customerPage();
            customerForm.Show();
            this.Hide();
        }

        private void managerBtn_Click(object sender, EventArgs e)
        {
            Manager managerForm = new Manager();
            managerForm.Show();
            this.Hide();
        }

    }
}
