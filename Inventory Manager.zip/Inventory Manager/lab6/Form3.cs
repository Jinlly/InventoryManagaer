﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Manager : Form
    {
        public Manager()
        {
            InitializeComponent();
        }

        private void Manager_Load(object sender, EventArgs e)
        {
            DataTable storageVt = new DataTable();
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\1.accdb";
            string query = "SELECT * FROM Storage";
            try
            {
                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connectionString))
                {
                    adapter.Fill(storageVt);
                }
                storageGridView.DataSource = storageVt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void refillBtn_Click(object sender, EventArgs e)
        {
            string productId = refillBox.Text.Trim();
            string refillAmountStr = refillNumberBox.Text.Trim();
            int refillAmount;

            if (string.IsNullOrEmpty(productId) || string.IsNullOrEmpty(refillAmountStr) || !int.TryParse(refillAmountStr, out refillAmount))
            {
                MessageBox.Show("Please enter a valid Product ID and Refill Amount.");
                return;
            }

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\1.accdb";
            string updateQuery = "UPDATE Storage SET Quantity = Quantity + ? WHERE ID = ?";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("?", refillAmount);
                        cmd.Parameters.AddWithValue("?", productId);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Stock updated successfully.");
                            Manager_Load(null, null); 
                        }
                        else
                        {
                            MessageBox.Show("Product not found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating stock: {ex.Message}");
            }
        }

        private void storageGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
         
        }

        private void refillBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void refillNumberBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void orderBtn_Click(object sender, EventArgs e)
        {
            orderNewForm newOrderForm = new orderNewForm();
            this.Hide();
            newOrderForm.Show();
        }

        private void IDSearchBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void oldPriceBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void newPriceBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void searchBtn_Click(object sender, EventArgs e)
        {
            string searchDescription = searchingDesBox.Text.Trim().ToLower();
            string searchBrand = searchBrandBox.Text.Trim().ToLower(); 
            int matchCount = 0;
            DataGridViewRow lastMatchedRow = null;

            storageGridView.ClearSelection();

            foreach (DataGridViewRow row in storageGridView.Rows)
            {
                string rowDescription = row.Cells["Description"].Value?.ToString().ToLower() ?? "";
                string rowBrand = row.Cells["Brand"].Value?.ToString().ToLower() ?? "";

                bool descriptionMatches = string.IsNullOrEmpty(searchDescription) || rowDescription.Contains(searchDescription);
                bool brandMatches = string.IsNullOrEmpty(searchBrand) || rowBrand.Contains(searchBrand);

                if (descriptionMatches && brandMatches)
                {
                    row.Selected = true;
                    matchCount++;
                    lastMatchedRow = row;
                }
            }

            if (matchCount == 1)
            {

                IDSearchBox.Text = lastMatchedRow.Cells["ID"].Value?.ToString() ?? "ID Unknown";
            }
            else if (matchCount > 1)
            {
                IDSearchBox.Text = "more than one item";
            }
            else
            {
                IDSearchBox.Text = "No matching item";
            }
        }


        private void priceChangeBtn_Click(object sender, EventArgs e)
        {
            string productId = IDSearchBox.Text.Trim();
            string newPriceStr = newPriceBox.Text.Trim();
            decimal newPrice;

            if (string.IsNullOrEmpty(productId) || string.IsNullOrEmpty(newPriceStr) || !decimal.TryParse(newPriceStr, out newPrice))
            {
                MessageBox.Show("Please enter valid Product ID and New Price.");
                return;
            }

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\1.accdb";
            string updateQuery = "UPDATE Storage SET Price = ? WHERE ID = ?";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("?", newPrice);
                        cmd.Parameters.AddWithValue("?", productId);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Price updated successfully.");
                            Manager_Load(null, null);
                        }
                        else
                        {
                            MessageBox.Show("Product not found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating price: {ex.Message}");
            }
        }

        private void searchingDesBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void searchBrandBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

