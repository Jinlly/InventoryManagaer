﻿namespace Lab6
{
    partial class customerPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buyNumberBox = new System.Windows.Forms.RichTextBox();
            this.searchBtn = new System.Windows.Forms.Button();
            this.orderBtn = new System.Windows.Forms.Button();
            this.storageGridView = new System.Windows.Forms.DataGridView();
            this.stockLabel = new System.Windows.Forms.Label();
            this.itemDesBox = new System.Windows.Forms.RichTextBox();
            this.itemBrandBox = new System.Windows.Forms.RichTextBox();
            this.desLabel = new System.Windows.Forms.Label();
            this.brandLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.idBox = new System.Windows.Forms.RichTextBox();
            this.idLabel = new System.Windows.Forms.Label();
            this.itempictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.storageGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itempictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // buyNumberBox
            // 
            this.buyNumberBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buyNumberBox.Location = new System.Drawing.Point(208, 319);
            this.buyNumberBox.Name = "buyNumberBox";
            this.buyNumberBox.Size = new System.Drawing.Size(57, 35);
            this.buyNumberBox.TabIndex = 2;
            this.buyNumberBox.Text = "";
            this.buyNumberBox.TextChanged += new System.EventHandler(this.buyNumberBox_TextChanged);
            // 
            // searchBtn
            // 
            this.searchBtn.Location = new System.Drawing.Point(101, 261);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(75, 23);
            this.searchBtn.TabIndex = 3;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseVisualStyleBackColor = true;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // orderBtn
            // 
            this.orderBtn.Location = new System.Drawing.Point(101, 360);
            this.orderBtn.Name = "orderBtn";
            this.orderBtn.Size = new System.Drawing.Size(75, 23);
            this.orderBtn.TabIndex = 4;
            this.orderBtn.Text = "Order!";
            this.orderBtn.UseVisualStyleBackColor = true;
            this.orderBtn.Click += new System.EventHandler(this.orderBtn_Click);
            // 
            // storageGridView
            // 
            this.storageGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.storageGridView.Location = new System.Drawing.Point(548, 100);
            this.storageGridView.Name = "storageGridView";
            this.storageGridView.Size = new System.Drawing.Size(206, 270);
            this.storageGridView.TabIndex = 5;
            this.storageGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.storageGridView_CellContentClick);
            // 
            // stockLabel
            // 
            this.stockLabel.AutoSize = true;
            this.stockLabel.Location = new System.Drawing.Point(545, 84);
            this.stockLabel.Name = "stockLabel";
            this.stockLabel.Size = new System.Drawing.Size(103, 13);
            this.stockLabel.TabIndex = 6;
            this.stockLabel.Text = "Availiable On Stock:";
            // 
            // itemDesBox
            // 
            this.itemDesBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemDesBox.Location = new System.Drawing.Point(22, 220);
            this.itemDesBox.Name = "itemDesBox";
            this.itemDesBox.Size = new System.Drawing.Size(118, 35);
            this.itemDesBox.TabIndex = 7;
            this.itemDesBox.Text = "";
            this.itemDesBox.TextChanged += new System.EventHandler(this.itemDesBox_TextChanged);
            // 
            // itemBrandBox
            // 
            this.itemBrandBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemBrandBox.Location = new System.Drawing.Point(146, 220);
            this.itemBrandBox.Name = "itemBrandBox";
            this.itemBrandBox.Size = new System.Drawing.Size(119, 35);
            this.itemBrandBox.TabIndex = 8;
            this.itemBrandBox.Text = "";
            this.itemBrandBox.TextChanged += new System.EventHandler(this.itemBrandBox_TextChanged);
            // 
            // desLabel
            // 
            this.desLabel.AutoSize = true;
            this.desLabel.Location = new System.Drawing.Point(48, 204);
            this.desLabel.Name = "desLabel";
            this.desLabel.Size = new System.Drawing.Size(76, 13);
            this.desLabel.TabIndex = 9;
            this.desLabel.Text = "Search a Item:";
            // 
            // brandLabel
            // 
            this.brandLabel.AutoSize = true;
            this.brandLabel.Location = new System.Drawing.Point(165, 204);
            this.brandLabel.Name = "brandLabel";
            this.brandLabel.Size = new System.Drawing.Size(84, 13);
            this.brandLabel.TabIndex = 10;
            this.brandLabel.Text = "Search a Brand:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(155, 303);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "How Many you want?";
            // 
            // idBox
            // 
            this.idBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.idBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idBox.Location = new System.Drawing.Point(22, 319);
            this.idBox.Name = "idBox";
            this.idBox.ReadOnly = true;
            this.idBox.Size = new System.Drawing.Size(180, 35);
            this.idBox.TabIndex = 12;
            this.idBox.Text = "";
            this.idBox.TextChanged += new System.EventHandler(this.idBox_TextChanged);
            // 
            // idLabel
            // 
            this.idLabel.AutoSize = true;
            this.idLabel.Location = new System.Drawing.Point(34, 303);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(44, 13);
            this.idLabel.TabIndex = 13;
            this.idLabel.Text = "Item ID:";
            // 
            // itempictureBox
            // 
            this.itempictureBox.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.itempictureBox.Location = new System.Drawing.Point(296, 100);
            this.itempictureBox.Name = "itempictureBox";
            this.itempictureBox.Size = new System.Drawing.Size(217, 270);
            this.itempictureBox.TabIndex = 14;
            this.itempictureBox.TabStop = false;
            this.itempictureBox.Click += new System.EventHandler(this.itempictureBox_Click);
            // 
            // customerPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.itempictureBox);
            this.Controls.Add(this.idLabel);
            this.Controls.Add(this.idBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.brandLabel);
            this.Controls.Add(this.desLabel);
            this.Controls.Add(this.itemBrandBox);
            this.Controls.Add(this.itemDesBox);
            this.Controls.Add(this.stockLabel);
            this.Controls.Add(this.storageGridView);
            this.Controls.Add(this.orderBtn);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.buyNumberBox);
            this.Name = "customerPage";
            this.Text = "Customer";
            this.Load += new System.EventHandler(this.CustomerPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.storageGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itempictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RichTextBox buyNumberBox;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.Button orderBtn;
        private System.Windows.Forms.DataGridView storageGridView;
        private System.Windows.Forms.Label stockLabel;
        private System.Windows.Forms.RichTextBox itemDesBox;
        private System.Windows.Forms.RichTextBox itemBrandBox;
        private System.Windows.Forms.Label desLabel;
        private System.Windows.Forms.Label brandLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox idBox;
        private System.Windows.Forms.Label idLabel;
        private System.Windows.Forms.PictureBox itempictureBox;
    }
}