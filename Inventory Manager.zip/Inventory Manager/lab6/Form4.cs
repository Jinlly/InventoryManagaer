﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class orderNewForm : Form
    {
        public orderNewForm()
        {
            InitializeComponent();
        }

        private void newDesBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void newBrandBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void newQuantityBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void newItemPriceBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            // Input validation
            if (string.IsNullOrWhiteSpace(newDesBox.Text) ||
                string.IsNullOrWhiteSpace(newBrandBox.Text) ||
                !int.TryParse(newQuantityBox.Text, out int quantity) ||
                !decimal.TryParse(newItemPriceBox.Text, out decimal price))
            {
                MessageBox.Show("Please fill in all fields with valid values.");
                return;
            }

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\1.accdb";
            string sqlCheck = "SELECT COUNT(*) FROM Storage WHERE Description = ? AND Brand = ?";

            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    using (OleDbCommand checkCmd = new OleDbCommand(sqlCheck, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@Description", newDesBox.Text);
                        checkCmd.Parameters.AddWithValue("@Brand", newBrandBox.Text);

                        int productExists = (int)checkCmd.ExecuteScalar();

                        if (productExists > 0)
                        {
                            MessageBox.Show("A product with the same description and brand already exists.");
                            return; 
                        }
                    }

                    string sqlInsert = "INSERT INTO Storage (Description, Brand, Quantity, Price) VALUES (?, ?, ?, ?)";
                    using (OleDbCommand insertCmd = new OleDbCommand(sqlInsert, connection))
                    {
                        insertCmd.Parameters.AddWithValue("@Description", newDesBox.Text);
                        insertCmd.Parameters.AddWithValue("@Brand", newBrandBox.Text);
                        insertCmd.Parameters.AddWithValue("@Quantity", quantity);
                        insertCmd.Parameters.AddWithValue("@Price", price);

                        int result = insertCmd.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Product added successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Product was not added. Please try again.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to add product: {ex.Message}");
            }
        }




        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Manager managerForm = new Manager();
            managerForm.Show();
        }
    }
}
