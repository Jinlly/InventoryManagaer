﻿namespace Lab6
{
    partial class orderNewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.newDesBox = new System.Windows.Forms.RichTextBox();
            this.newBrandBox = new System.Windows.Forms.RichTextBox();
            this.newQuantityBox = new System.Windows.Forms.RichTextBox();
            this.newItemPriceBox = new System.Windows.Forms.RichTextBox();
            this.addBtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(224, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Description:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(317, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Brand:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(400, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantity:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(482, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Price:";
            // 
            // newDesBox
            // 
            this.newDesBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newDesBox.Location = new System.Drawing.Point(227, 191);
            this.newDesBox.Name = "newDesBox";
            this.newDesBox.Size = new System.Drawing.Size(76, 38);
            this.newDesBox.TabIndex = 4;
            this.newDesBox.Text = "";
            this.newDesBox.TextChanged += new System.EventHandler(this.newDesBox_TextChanged);
            // 
            // newBrandBox
            // 
            this.newBrandBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newBrandBox.Location = new System.Drawing.Point(309, 191);
            this.newBrandBox.Name = "newBrandBox";
            this.newBrandBox.Size = new System.Drawing.Size(76, 38);
            this.newBrandBox.TabIndex = 5;
            this.newBrandBox.Text = "";
            this.newBrandBox.TextChanged += new System.EventHandler(this.newBrandBox_TextChanged);
            // 
            // newQuantityBox
            // 
            this.newQuantityBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newQuantityBox.Location = new System.Drawing.Point(391, 191);
            this.newQuantityBox.Name = "newQuantityBox";
            this.newQuantityBox.Size = new System.Drawing.Size(76, 38);
            this.newQuantityBox.TabIndex = 6;
            this.newQuantityBox.Text = "";
            this.newQuantityBox.TextChanged += new System.EventHandler(this.newQuantityBox_TextChanged);
            // 
            // newItemPriceBox
            // 
            this.newItemPriceBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newItemPriceBox.Location = new System.Drawing.Point(473, 191);
            this.newItemPriceBox.Name = "newItemPriceBox";
            this.newItemPriceBox.Size = new System.Drawing.Size(76, 38);
            this.newItemPriceBox.TabIndex = 7;
            this.newItemPriceBox.Text = "";
            this.newItemPriceBox.TextChanged += new System.EventHandler(this.newItemPriceBox_TextChanged);
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(350, 235);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(75, 23);
            this.addBtn.TabIndex = 8;
            this.addBtn.Text = "Add";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(350, 264);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(75, 23);
            this.backBtn.TabIndex = 9;
            this.backBtn.Text = "Back";
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // orderNewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.newItemPriceBox);
            this.Controls.Add(this.newQuantityBox);
            this.Controls.Add(this.newBrandBox);
            this.Controls.Add(this.newDesBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "orderNewForm";
            this.Text = "Order New";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox newDesBox;
        private System.Windows.Forms.RichTextBox newBrandBox;
        private System.Windows.Forms.RichTextBox newQuantityBox;
        private System.Windows.Forms.RichTextBox newItemPriceBox;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button backBtn;
    }
}