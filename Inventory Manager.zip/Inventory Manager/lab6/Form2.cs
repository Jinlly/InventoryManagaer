﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class customerPage : Form
    {
        DataTable storageVt = new DataTable();
        string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\1.accdb";
        string query = "SELECT * FROM Storage";

        public customerPage()
        {
            InitializeComponent();
        }

        private void CustomerPage_Load(object sender, EventArgs e)
        {

            try
            {
                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connectionString))
                {
                    adapter.Fill(storageVt);
                }
                storageGridView.DataSource = storageVt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }

        }

        private void storageGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void itemDesBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void itemBrandBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void buyNumberBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            string searchDescription = itemDesBox.Text.Trim().ToLower();
            string searchBrand = itemBrandBox.Text.Trim().ToLower();
            int matchCount = 0;
            DataGridViewRow lastMatchedRow = null;

            storageGridView.ClearSelection();

            foreach (DataGridViewRow row in storageGridView.Rows)
            {
                string rowDescription = row.Cells["Description"].Value?.ToString().ToLower() ?? "";
                string rowBrand = row.Cells["Brand"].Value?.ToString().ToLower() ?? "";

                bool descriptionMatches = string.IsNullOrEmpty(searchDescription) || rowDescription.Contains(searchDescription);
                bool brandMatches = string.IsNullOrEmpty(searchBrand) || rowBrand.Contains(searchBrand);

                if (descriptionMatches && brandMatches)
                {
                    row.Selected = true;
                    matchCount++;
                    lastMatchedRow = row;
                }
            }

            if (matchCount == 1)
            {
                idBox.Text = lastMatchedRow.Cells["ID"].Value?.ToString() ?? "ID Unknown";
                string imagePath = lastMatchedRow.Cells["Pictures"].Value?.ToString();
                if (!string.IsNullOrEmpty(imagePath))
                {
                    itempictureBox.Image = Image.FromFile(imagePath); 
                }
            }
            else if (matchCount > 1)
            {
                idBox.Text = "more than one item";
                itempictureBox.Image = null; 
            }
            else
            {
                idBox.Text = "No matching item";
                itempictureBox.Image = null; 
            }
        }


        private void orderBtn_Click(object sender, EventArgs e)
        {
            if (storageGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an item to order.");
                return;
            }
            if (!int.TryParse(buyNumberBox.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Please enter a valid quantity.");
                return;
            }

            string itemId = storageGridView.SelectedRows[0].Cells["ID"].Value.ToString();
            string orderQuery = $"INSERT INTO Orders (ItemID, Quantity) VALUES (?, ?)";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(orderQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("?", itemId);
                        cmd.Parameters.AddWithValue("?", quantity);
                        int result = cmd.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Order placed successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Failed to place order.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error placing order: {ex.Message}");
            }
        }

        private void idBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void itempictureBox_Click(object sender, EventArgs e)
        {
            
        }
    }
}
